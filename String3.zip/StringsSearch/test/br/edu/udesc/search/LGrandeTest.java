package br.edu.udesc.search;

import org.junit.*;

public class LGrandeTest 
{
	public static String LGrande;
	public static String WORD = "ipsum";
	
	
	@Before
	public void readFile()
	{
		LGrande = Read.readFile("resource/lipsumgrande.txt");
	}

	
	@Test
	public void NaiveTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByNaiveStrategy());
		ctx.search(LGrande, WORD);
	}
	
	@Test
	public void RabinKarpTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByRabinKarpStrategy());
		ctx.search(LGrande, WORD);
	}
	
	@Test
	public void BoyerMooreTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByBoyerMooreStrategy());
		ctx.search(LGrande, WORD);
	}
	
	@Test
	public void KMPTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByKMPStrategy());
		ctx.search(LGrande, WORD);
	}
	
}
