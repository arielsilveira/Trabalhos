package br.edu.udesc.search;

import org.junit.*;

public class LPequenoTest 
{
	public static String LPequeno;
	public static String WORD = "ipsum";
	
	
	@Before
	public void readFile()
	{
		LPequeno = Read.readFile("resource/lipsumpequeno.txt");
	}

	
	@Test
	public void NaiveTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByNaiveStrategy());
		ctx.search(LPequeno, WORD);
	}
	
	@Test
	public void RabinKarpTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByRabinKarpStrategy());
		ctx.search(LPequeno, WORD);
	}
	
	@Test
	public void BoyerMooreTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByBoyerMooreStrategy());
		ctx.search(LPequeno, WORD);
	}
	
	@Test
	public void KMPTest()
	{
		SearchContext ctx = new SearchContext();
		ctx.setSearchStrategy(new SearchByKMPStrategy());
		ctx.search(LPequeno, WORD);
	}
	
}