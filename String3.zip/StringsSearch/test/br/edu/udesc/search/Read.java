package br.edu.udesc.search;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Read 
{
	public static String readFile(String nameFile)
	{
			File   fi =  new File(nameFile);

			try(FileReader     fr = new FileReader(fi);
				BufferedReader br = new BufferedReader(fr) ) 
			{
				String sCurrentLine;
				StringBuilder builder = new StringBuilder();
				while ((sCurrentLine = br.readLine()) != null) {
					builder.append(sCurrentLine);
				}
				return builder.toString();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "";
	}
}
