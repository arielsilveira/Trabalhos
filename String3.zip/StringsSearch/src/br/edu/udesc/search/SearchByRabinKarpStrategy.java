package br.edu.udesc.search;


/**
 * Pesquisa de uma string em um texto usando o método Rabin-Karp
 * @author udesc
 *
 */
public class SearchByRabinKarpStrategy extends ASearchStrategy 
{
	
	/**
	 * @param content texto de entrada
	 * @param word palavra a procurar
	 * @return numero de ocorrencias da palavra no texto
	 */
	public int searchFile(String content, String word)
	{
		
		  int cont = 0;
		  int sizeContent = content.length();
		  int sizeWord = word.length();
		  
		  int hashOfPatt = word.hashCode(); 

		  for(int i = 0; i < sizeContent; i++)
		  {
			   if(i + sizeWord + 1 <= sizeContent)
			   {
				   String sub = content.substring(i, i + sizeWord);
		
				   int hashSub = sub.hashCode(); 
		
				   if(hashOfPatt == hashSub)
				   { 
			
					    int k = 0;
					    boolean d = true;
			
					    for(int j = i; j < i + sizeWord; j++)
					    {
						    if(content.charAt(j) == word.charAt(k))
						    { 
						    	k++;      
						    }
						    else
						    {
						    	d = false;
						    	break; 
						    }      
					    }
					     
					    if(d)
					    	cont++; 
				    }
			   }   
		  } 
		return cont;
	}
}