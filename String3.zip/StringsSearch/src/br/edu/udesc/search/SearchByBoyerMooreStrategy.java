package br.edu.udesc.search;

/**
 * Pesquisa de uma string em um texto usando o método Booyer-Moore
 * @author udesc
 *
 */
public class SearchByBoyerMooreStrategy extends ASearchStrategy 
{
	
	private int RAD = 256;
	private int[] last = new int[RAD];
	
	
	/**
	 * @param content texto de entrada
	 * @param word palavra a procurar
	 * @return numero de ocorrencias da palavra no texto
	 */
	public int searchFile(String content, String word) 
	{
		for(int i = 0; i < RAD; i++){
			last[i] = -1;
		}
		for(int i = 0; i < word.length(); i++){
			last[word.charAt(i)] = i;
		}
		
		int sizeContent = content.length();
		int sizeWord = word.length();
		int skip = 0;
		int cont = 0;
		for(int i = 0; i < sizeContent - sizeWord; i += skip){
			skip = 0;
			for(int j = sizeWord - 1; j >= 0; j--){
				if(word.charAt(j) != content.charAt(i + j)){
					skip = Math.max(1, j - last[content.charAt(i + j)]);
					break;
				}
			}
			if(skip == 0){
				cont++;
				skip = 1;
				
			}
		}
		
		
		return cont;
		
	}

}
