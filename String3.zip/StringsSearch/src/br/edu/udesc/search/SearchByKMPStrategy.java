package br.edu.udesc.search;


/**
 * Pesquisa de uma string em um texto usando o método KMP
 * @author udesc
 *
 */
public class SearchByKMPStrategy extends ASearchStrategy 
{
	
	private int[] vetor;
	
	
	/**
	 * @param word palavra a ser preprocessada
	 */
	private void preProcess(String word)
	{
		int i = 1, j = 0;
		int sizeWord = word.length();
		vetor[0] = 0;
		while(i < sizeWord)
		{
			if(word.charAt(i) == word.charAt(j))
			{
				j++;
				vetor[i++] = j;
			} 
			else 
			{
				if(j != 0)
				{
					j = vetor[j - 1];
				} 
				else 
				{
					vetor[i++] = 0;
				}
			}
		}
	}
	
	
	/**
	 * @param content texto de entrada
	 * @param word palavra a procurar
	 * @return numero de ocorrencias da palavra no texto
	 */
	public int searchFile(String content, String word) 
	{
		this.vetor = new int[word.length() + 1];
		preProcess(word);
		int cont = 0;
		int i = 0, j = 0;
		int sizeContent = content.length();
		int sizeWord = word.length();
		while(i < sizeContent){
			if(word.charAt(j) == content.charAt(i))
			{
				i++;
				j++;
			}
			if(j == sizeWord)
			{
				cont++;
				j = vetor[j - 1];
			} 
			else if(i < sizeContent && word.charAt(j) != content.charAt(i))
			{
				if(j != 0)
				{
					j = vetor[j - 1];
				} 
				else 
				{
					i++;
				}
			}
		}
		return cont;
	}



}
