package br.edu.udesc.search;

/**
 * Pesquisa usando o m�todo da for�a bruta (Naive)
 * @author udesc
 *
 */
public class SearchByNaiveStrategy extends ASearchStrategy {
	/**
	 * @param content texto de entrada
	 * @param word palavra a procurar
	 * @return numero de ocorrencias da palavra no texto
	 */
	public int searchFile(String content, String word) {
		int n = content.length();
		int m = word.length();
		int cont = 0;
		for (int i = 0; i < n - m; i++) {
			int j = 0;
			while (j < m && content.charAt(i + j) == word.charAt(j)) {
				j++;
			}
			if (j == m){
				cont++;
			}				
		}
		return cont;
	}

}
