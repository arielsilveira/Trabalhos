package br.edu.udesc.search;

public interface ISearchStrategy {
     public int searchFile(String content,String word);
}