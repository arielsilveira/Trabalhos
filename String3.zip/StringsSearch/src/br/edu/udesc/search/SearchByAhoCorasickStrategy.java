package br.edu.udesc.search;

public class SearchByAhoCorasickStrategy extends ASearchStrategy 
{
	public int searchFile(String content, String word) 
	{
		int cont = 0;
		
		
		return cont;
	}
	
}