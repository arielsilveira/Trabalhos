package br.edu.udesc.search;

public abstract class ASearchStrategy implements ISearchStrategy{
	 public static final int NOT_FOUND = 0;
}
